# UBinstaller-ubuntu
Ubilling Ubuntu installation script

1. Ubuntu-server 14.04.x LTS installed without any services other than OpenSSH
2. apt-get update
3. apt-get upgrade
4. ./ubuntustaller.sh
