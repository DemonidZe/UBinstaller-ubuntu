# UBinstaller-ubuntu
Ubilling Ubuntu installation script
1. Ubuntu-server 18.04.x or 16.04.x LTS installed without any services other than OpenSSH
2. apt-get update
3. apt-get upgrade
4. download UBinstaller-ubuntu/18.04_LTS/*
5. chmod a+x UBistaller_ubuntu.sh
6. ./UBistaller_ubuntu.sh
