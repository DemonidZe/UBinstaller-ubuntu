# UBinstaller-ubuntu
Ubilling Ubuntu installation script
For ubuntu 14.04, 16.04, 18.04

1. Ubuntu-server LTS installed without any services other than OpenSSH
2. apt-get update
3. apt-get upgrade
4. ./ubuntustaller.sh
